
public enum PlayerName {
	Player1,
	Player2,
	none
}
