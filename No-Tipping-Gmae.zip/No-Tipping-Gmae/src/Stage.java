
public enum Stage {
	addition, removal
}
